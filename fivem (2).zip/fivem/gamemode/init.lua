 AddCSLuaFile("share.lua")
 AddCSLuaFile("cl_init.lua")
 AddCSLuaFile("jobs.lua")
 AddCSLuaFile("sv_interface.lua")
 AddCSLuaFile("sv_jobs.lua")
 AddCSLuaFile("sh_commands.lua")

include("shared.lua")
include("jobs.lua")
	

local Team_Police, TEAM_SHERIFF, TEAM_STATEPATROLE, TEAM_CIVILIAN = 1, 2, 3, 4


function GM:PlayerSpaw( ply )
	ply:ChatPrint( "You have spawned !" )
	print( "player: " .. ply:nick() .. " has spawned!" )
	
		ply:SetGravity( 1 )
		ply:SetWalkSpeed( 250 )
		ply:SetRunSpeed( 350 )
		ply:SetCrouchedWalkSpeed( 0.4 )
		ply:SetDuckSpeed( 0.6 )
		ply:Set NocolideWithTeammates( false )
		ply:SendLua( [[chat.AddText( 80, 45, 140 |, "Welcome to the server!]] .. ply:Nick{) .. |(|" >|])
end

-----Fill in the blanks	
function GM:PlayerLoadout( ply )
//ply:Give( "_________" )
//ply:GiveAmmo( 24, "___", true )
end

function GM:PlayerDeath( ply, inf, att )
	timer.Destroy( "HPRegen_" ..ply:UniqueId() )
	if ply != att then
		ply:AddAmmo( 64 )
		if att:IsPlayer() and IsValid( att ) then
			if ply.lasting and ply.lasthg == HITGROUP HEAD then
			