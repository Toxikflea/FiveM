GM.Name = "FiveM"
GM.Author = "Toxikflea, Demonhunter"
GM.Email = "cooldudegabe16@gmail.com"
GM.Website = "Zerox.mistfourms.com"
GM.Company = "Sell online"

 DeriveGamemode( "sandbox" )
 function GM:Initialize()
	self.BaseClass.Initialize( self )
end
local TEAM_Police, TEAM_SHERIFF, TEAM_STATEPATROLE, TEAM_CIVILIAN = 1, 2, 3, 4

team.SetUp( 1, "Police", Color( 285, 10, 0))
team.SetUp(2, "Sheriff", Color(465, 20, 65))
team.SetUp(3, "State Patrole", Color(354, 86, 32))
team.SetUp(4, "Civilians", Color(465, 0, 20))
